import React from "react";
import { useState, useEffect } from "react";
function DrawPage() {
    sleep(8000);
    return (
        <div style={{ textAlign: "center" }}>
            <img
                style={{
                    height: "300px",
                    width: "300px",
                }}
                src="http://localhost:4000/uploads/1652945320021_%E1%84%83%E1%85%A1%E1%84%8B%E1%85%AE%E1%86%AB%E1%84%85%E1%85%A9%E1%84%83%E1%85%B3%20(1).png"
                alt="합성이미지"
            />
        </div>
    );
}
function sleep(ms) {
    const wakeUpTime = Date.now() + ms;
    while (Date.now() < wakeUpTime) {}
}
export default DrawPage;
